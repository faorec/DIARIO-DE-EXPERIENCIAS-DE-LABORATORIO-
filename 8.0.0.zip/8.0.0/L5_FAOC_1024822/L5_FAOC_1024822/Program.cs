﻿using System;

int numeroEntero = 0;

//Mensaje en pantalla//

Console.WriteLine("EJERCICIO 1");
Console.WriteLine("Numero Entero");

//siguiente instruccion recibe y almacena el numero//
numeroEntero = Convert.ToInt32(Console.ReadLine());
if (numeroEntero >= 1)
{
    Console.WriteLine("Numero positivo");

}
else if (numeroEntero <= 1)
{
    Console.WriteLine("Numero negativo");
}
else if (numeroEntero==0)
{
    Console.WriteLine("El numero es 0");
}
Console.ReadKey();