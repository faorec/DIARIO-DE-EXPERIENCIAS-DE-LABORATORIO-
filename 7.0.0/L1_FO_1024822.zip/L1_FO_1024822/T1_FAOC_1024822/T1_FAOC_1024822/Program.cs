﻿class Program
{
    static void Main (string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        Console.ReadKey();

        Console.WriteLine("ingrese su Nombre: ");
        string sNombre = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Edad: ");
        string sEdad = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Carrera");
        string sCarrera = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("ingrese su Carné: ");
        string sCarné = Console.ReadLine();
        Console.ReadKey();
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carné: " + sCarné);

        Console.WriteLine("Soy " + sNombre + "tengo" + sEdad + "años y estudio la carrera de" + sCarrera + "Mi número de carné es" + sCarné + ".");
        Console.ReadKey();

    }
 

}


