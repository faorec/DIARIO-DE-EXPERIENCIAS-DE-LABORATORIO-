﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hola Mundo soy Fryda");
        Console.ReadKey();

        /* AGREGAR, EJECUTAR Y DIFERENCIA ENTRE WRITELINE Y WIETE */
        /* La diferencia es que, writeline se usa para imprimir datos junto con
         * la impresión de nuevas lineas que se agreguen. */
        /* Por otro lado,write sirve para imprimir información sin imprimir en 
         * la nueva línea que se agregue*/

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy Fryda");

        Console.Write("Hola Mundo");
        Console.Write("Soy Fryda");
        Console.ReadKey();

        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy" + Nombre);

        /* COMENTARIOS */

        Console.Write("Hola Mundo ");
        Console.Write("Soy " + Nombre);
        Console.ReadKey();
    }
}

