﻿ class Program
    {
        static void Main(string[] args)
        {
            int cantidad = 0;
            int contador = 0;
            string usuario;
            string contraseña;
            bool res = false;


            while (cantidad < 3)
            {
                Console.WriteLine("Ingresar usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingresar contraseña");
                contraseña = Console.ReadLine();

                res = login(usuario, contraseña);
                if (res == true)
                {
                    cantidad = 3;
                    Console.WriteLine("Bienvenido");
                }
                else
                {
                    Console.WriteLine("Error ingrese de nuevo el usuario y contraseña, su cantidad de intentos es: " + contador);
                    contador++;
                    cantidad++;
                }
                if (contador == 3)
                {
                    Console.WriteLine("Ha llegado al limite de oportunidades");
                }

            }

            Console.ReadKey();
        }
        public static bool login(string usuario, string contraseña)
        {
            if (usuario == "usuario1" && contraseña == "asdasd")
            {
                return true;
            }
            else
            {
                return false;

            }
        }
    }
