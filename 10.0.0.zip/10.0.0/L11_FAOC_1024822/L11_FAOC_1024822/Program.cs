﻿class Program
{
    static void Main(string[] args)
    {

        int valor;
        double cantidad;

        
        Console.WriteLine("Ingrese 1 para convertir desde libras, ingrese 2 para convertir desde dolares, ingrese 3 para convertir desde yen.");
        valor = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingresar la cantidad que se desea convertir");

        cantidad = Convert.ToDouble(Console.ReadLine());
        
        {
            double resultado = operaciones(valor, cantidad);
            Console.WriteLine("Su cantidad es : " + resultado);
        }


    }


    static double operaciones(int valor, double cantidad)
    {
        if (valor == 1)
        {
            return cantidad * 1.22;
        }

        if (valor == 2)
        {
            return cantidad * 0.75;
        }

        else 
        {
            return cantidad * 0.009;
        }

        Console.ReadKey();
    }


}
